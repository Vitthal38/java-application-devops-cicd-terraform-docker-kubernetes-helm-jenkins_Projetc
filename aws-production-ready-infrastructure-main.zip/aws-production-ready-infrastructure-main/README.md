# Production-Ready AWS Infrastructure

This project demonstrates how to build a highly available and scalable AWS infrastructure using core AWS services.

## Architecture
- Custom VPC with public and private subnets
- NAT Gateway for secure outbound internet access
- Application Load Balancer
- EC2 Launch Template
- Auto Scaling Group
- CloudWatch monitoring
- SNS alert notifications
- CloudTrail audit logging

## AWS Services Used
IAM
VPC
NAT Gateway
ALB
EC2
Auto Scaling
CloudWatch
CloudTrail
SNS

## Region
ap-south-1 (Mumbai)

## Architecture Diagram
![Architecture](architecture-diagram.png)

## Project Documentation
See the full documentation here:
Production_Ready_AWS_Infrastructure.pdf
